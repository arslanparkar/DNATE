import { cookies } from 'next/headers';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const cookieStore = cookies();
  const token = cookieStore.get('token')?.value;
  const { id } = params;

  if (!token) {
    return new Response(JSON.stringify({ error: 'Not authenticated' }), { status: 401 });
  }

  if (!id) {
    return new Response(JSON.stringify({ error: 'Session ID is required' }), { status: 400 });
  }

  try {
    const apiRes = await fetch(`${API_BASE_URL}/api/sessions/${id}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const data = await apiRes.json();

    if (!apiRes.ok) {
      return new Response(JSON.stringify(data), { status: apiRes.status });
    }

    return new Response(JSON.stringify(data), { status: 200 });

  } catch (error) {
    console.error(`Fetch session ${id} error:`, error);
    return new Response(JSON.stringify({ error: 'Failed to fetch session details' }), { status: 500 });
  }
}